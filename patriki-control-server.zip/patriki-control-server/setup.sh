#!/usr/bin/env bash
# Установка «Патрики Контроль» на облачный сервер Ubuntu 22.04/24.04.
# Запуск от root:  bash setup.sh
# Что делает: ставит Node.js и Caddy (HTTPS-сертификат автоматически),
# копирует приложение в /opt/patriki, спрашивает пароль пользователя iiko,
# создаёт ключ доступа и службу, которая сама поднимается после перезагрузки.
set -euo pipefail

if [ "$(id -u)" != "0" ]; then echo "Запустите от root: sudo bash setup.sh"; exit 1; fi
SRC="$(cd "$(dirname "$0")" && pwd)"
APP=/opt/patriki

echo "== 1/6 Пакеты"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nodejs caddy openssl curl ufw >/dev/null
NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
if [ "$NODE_MAJOR" -lt 18 ]; then echo "Нужен Node.js 18+, установлен $(node -v). Возьмите образ Ubuntu 24.04."; exit 1; fi

echo "== 2/6 Файлы приложения"
id patriki >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin patriki
mkdir -p "$APP"
cp -r "$SRC"/src "$SRC"/public "$SRC"/demo "$SRC"/config.example.json "$APP"/

echo "== 3/6 Настройки"
if [ ! -f "$APP/config.json" ]; then
  read -r -p "Логин пользователя iiko для приложения [control_app]: " IIKO_LOGIN
  IIKO_LOGIN=${IIKO_LOGIN:-control_app}
  read -r -s -p "Пароль этого пользователя (не отображается): " IIKO_PASS; echo
  TOKEN=$(openssl rand -hex 24)
  IIKO_LOGIN="$IIKO_LOGIN" IIKO_PASS="$IIKO_PASS" TOKEN="$TOKEN" node -e '
    const fs=require("fs");const c=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));
    c.demo=false;c.host="127.0.0.1";c.port=8080;c.apiToken=process.env.TOKEN;
    c.venues.pet.iiko.login=process.env.IIKO_LOGIN;c.venues.pet.iiko.password=process.env.IIKO_PASS;
    fs.writeFileSync(process.argv[2],JSON.stringify(c,null,2));' "$APP/config.example.json" "$APP/config.json"
  unset IIKO_PASS
else
  echo "config.json уже есть — оставляю как есть."
  TOKEN=$(node -e 'console.log(require(process.argv[1]).apiToken)' "$APP/config.json")
fi
chown -R patriki:patriki "$APP"
chmod 600 "$APP/config.json"

echo "== 4/6 Проверка связи с iiko"
( cd "$APP" && sudo -u patriki TZ=Europe/Moscow node src/check.js ) || echo "!! Проверка не прошла — смотрите сообщение выше. Установка продолжится."

echo "== 5/6 Служба"
cat >/etc/systemd/system/patriki.service <<EOF
[Unit]
Description=Patriki Control
After=network-online.target
Wants=network-online.target

[Service]
User=patriki
WorkingDirectory=$APP
Environment=TZ=Europe/Moscow
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=5
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=$APP
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now patriki
systemctl restart patriki

echo "== 6/6 HTTPS"
IP=$(curl -4 -s --max-time 10 https://api.ipify.org || hostname -I | awk '{print $1}')
DOMAIN="${DOMAIN:-$(echo "$IP" | tr . -).sslip.io}"
cat >/etc/caddy/Caddyfile <<EOF
$DOMAIN {
  encode gzip
  reverse_proxy 127.0.0.1:8080
}
EOF
ufw allow 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
ufw --force enable >/dev/null
systemctl restart caddy
sleep 3

echo
echo "=============================================="
echo " Готово."
echo " Адрес приложения:  https://$DOMAIN"
echo " Ключ доступа:      $TOKEN"
echo
echo " Сохраните ключ в надёжном месте. Его вводят один раз на каждом"
echo " телефоне или компьютере. Сертификат HTTPS появится в течение минуты."
echo
echo " Полезное:"
echo "   journalctl -u patriki -n 50     — журнал приложения"
echo "   systemctl restart patriki       — перезапуск"
echo "=============================================="
