// Движок сверки «видео ↔ касса».
// Вход: события видеоаналитики (налив, выдача тарелки, ящик, отсутствие)
// и события iiko (позиции чеков, удаления, скидки, открытие ящика).
// Выход: список инцидентов с уровнем, суммой и ссылкой на фрагмент видео.

const MIN = 60 * 1000;

function within(a, b, ms) { return Math.abs(a - b) <= ms; }

function reconcile({ vision, pos, cfg }) {
  const incidents = [];
  const used = new Set();

  // 1. Налив / выдача без позиции в чеке.
  for (const v of vision.filter(e => e.type === "pour" || e.type === "plate_out")) {
    const rule = cfg.rules.unbilled;
    const cats = v.type === "pour" ? rule.pourCategories : rule.plateCategories;
    const match = pos.find((p, i) =>
      !used.has(i) && p.type === "sale_line" && cats.includes(p.category) &&
      p.ts - v.ts >= -rule.windowBeforeMin * MIN && p.ts - v.ts <= rule.windowAfterMin * MIN &&
      (!v.terminal || !p.terminal || v.terminal === p.terminal)
    );
    if (match) { used.add(pos.indexOf(match)); continue; }
    incidents.push(mk(v, "crit", v.type === "pour" ? "Налив без продажи" : "Блюдо ушло без заказа", {
      sum: v.estimatedPrice ?? null, employee: v.employee ?? null,
      evidence: [`Камера ${v.camera}: ${v.type === "pour" ? "налив" : "выдача"} (уверенность ${v.conf})`,
                 `Нет позиции категорий [${cats.join(", ")}] в окне ${rule.windowAfterMin} мин`],
    }));
  }

  // 2. Удаление после пречека.
  for (const p of pos.filter(e => e.type === "delete" && e.afterPrecheque)) {
    const paidOnCam = vision.find(v => v.type === "payment_at_table" && v.table === p.table && within(v.ts, p.ts, 20 * MIN));
    incidents.push(mk(p, paidOnCam ? "crit" : "warn", "Отмена после пречека", {
      sum: p.sum, employee: p.employee,
      evidence: [`iiko: заказ №${p.order} удалён, причина «${p.reason || "—"}»`, paidOnCam ? `Камера ${paidOnCam.camera}: оплата у стола` : "Оплата на видео не найдена"],
    }));
  }

  // 3. Ручная скидка выше лимита без карты гостя.
  for (const p of pos.filter(e => e.type === "discount" && e.percent > cfg.rules.discount.maxPercent && !e.loyaltyCard)) {
    incidents.push(mk(p, "warn", `Скидка ${p.percent}% без карты гостя`, {
      sum: p.discountSum, employee: p.employee, evidence: [`iiko: ручная скидка на заказ №${p.order}`],
    }));
  }

  // 4. Денежный ящик без чека.
  for (const p of pos.filter(e => e.type === "drawer_open")) {
    const win = cfg.rules.drawer.windowSec * 1000;
    const hasCheck = pos.some(c => c.type === "check_closed" && c.terminal === p.terminal && within(c.ts, p.ts, win));
    if (hasCheck) continue;
    incidents.push(mk(p, "warn", "Денежный ящик без чека", { sum: null, employee: p.employee, evidence: [`iiko: открытие ящика на ${p.terminal}`] }));
  }

  // 5. Отсутствие на рабочем месте и движение после закрытия — приходят готовыми из видеоаналитики.
  for (const v of vision.filter(e => e.type === "absent" && e.durationMin > cfg.rules.absence.maxMin)) {
    incidents.push(mk(v, "info", `Нет сотрудника на месте ${v.durationMin} мин`, { sum: null, employee: v.employee ?? null, evidence: [`Камера ${v.camera}: зона пуста`] }));
  }
  for (const v of vision.filter(e => e.type === "motion" && isClosed(e.ts, cfg.rules.closedHours))) {
    incidents.push(mk(v, "crit", "Движение после закрытия", { sum: null, employee: null, evidence: [`Камера ${v.camera}: движение в ${hhmm(v.ts)}`] }));
  }

  return incidents.sort((a, b) => b.ts - a.ts);
}

function mk(src, severity, title, extra) {
  return {
    id: `${src.venue || "pet"}-${+src.ts}-${title}`.replace(/\s+/g, "_"),
    venue: src.venue || "pet", ts: src.ts, severity, title,
    camera: src.camera || null, status: "new",
    clip: src.camera ? { camera: src.camera, from: new Date(+src.ts - 30000), to: new Date(+src.ts + 60000) } : null,
    ...extra,
  };
}
function hhmm(d) { return d.toTimeString().slice(0, 5); }
function isClosed(ts, [from, to]) {
  const h = ts.getHours() + ts.getMinutes() / 60;
  return from < to ? h >= from && h < to : h >= from || h < to;
}

module.exports = { reconcile };
