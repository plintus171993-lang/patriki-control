// Проверка подключения к iiko: node src\check.js
// 1) вход, 2) версия сервера, 3) выручка за вчера.
// Если отчёт не строится — пошаговая диагностика: какое поле или фильтр
// не принимает ваш сервер. Пароль на экран не выводится.
const fs = require("fs");
const path = require("path");
const { IikoClient } = require("./iiko");

const OLAP = "/resto/api/v2/reports/olap";

(async () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "config.json"), "utf8"));
  const c = new IikoClient(cfg.venues.pet.iiko);
  const d = new Date(Date.now() - 864e5);
  const from = d.toISOString().slice(0, 10), to = new Date().toISOString().slice(0, 10);
  const period = { "OpenDate.Typed": { filterType: "DateRange", periodType: "CUSTOM", from, to, includeLow: true, includeHigh: false } };

  try {
    console.log("Сервер:", c.baseUrl);
    await c.auth();
    console.log("Вход: OK");
    const ver = await c.request("/resto/api/version").catch((e) => "не удалось (" + e.message + ")");
    console.log("Версия сервера:", String(ver).trim());

    try {
      const rows = await c.sales(from, to, ["Department"]);
      printRows(rows);
      return;
    } catch (e) {
      console.log("\nПолный отчёт не построился:", e.message);
      console.log("\nДиагностика по шагам:");
    }

    const base = { reportType: "SALES", buildSummary: "false", groupByRowFields: ["Department"], filters: period };
    const step = async (name, body) => {
      try { await c.request(OLAP, { method: "POST", body }); console.log("  OK   ", name); return true; }
      catch (e) { console.log("  ОШИБКА", name, "→", e.message.replace(/^iiko \S+: /, "")); return false; }
    };

    await step("минимальный отчёт (выручка)", { ...base, aggregateFields: ["DishDiscountSumInt"] });
    for (const f of ["DishSumInt", "ProductCostBase.ProductCost", "UniqOrderId.OrdersCount", "GuestNum", "DishAmountInt"])
      await step("поле " + f, { ...base, aggregateFields: [f] });
    for (const g of ["HourOpen", "OpenTime", "DishName", "DishCategory", "OrderNum", "OrderWaiter.Name", "CashRegisterName", "RemovalType"])
      await step("группировка " + g, { ...base, groupByRowFields: ["Department", g], aggregateFields: ["DishDiscountSumInt"] });
    await step("фильтр DeletedWithWriteoff", { ...base, aggregateFields: ["DishDiscountSumInt"],
      filters: { ...period, DeletedWithWriteoff: { filterType: "IncludeValues", values: ["NOT_DELETED"] } } });
    await step("фильтр OrderDeleted", { ...base, aggregateFields: ["DishDiscountSumInt"],
      filters: { ...period, OrderDeleted: { filterType: "IncludeValues", values: ["NOT_DELETED"] } } });

    console.log("\nПришлите этот экран целиком — по строкам «ОШИБКА» поправлю запрос.");
  } catch (e) {
    console.error("Ошибка:", e.message);
  } finally {
    await c.logout();
  }

  function printRows(rows) {
    if (!rows.length) return console.log("За вчера продаж не найдено.");
    for (const r of rows) {
      const rev = Number(r.DishDiscountSumInt) || 0, cost = Number(r["ProductCostBase.ProductCost"]) || 0;
      console.log(`${r.Department}: выручка за ${from} — ${Math.round(rev).toLocaleString("ru-RU")} ₽, ` +
        `себестоимость ${Math.round(cost).toLocaleString("ru-RU")} ₽, чеков ${r["UniqOrderId.OrdersCount"]}`);
    }
    console.log("\nСверьте с iikoOffice. Если совпадает — касса подключена.");
  }
})();
