// Коннектор к iikoServer API (on-premise / iikoWeb-сервер точки).
// Авторизация: логин + SHA1 пароля -> токен. Токен занимает слот лицензии,
// поэтому после работы обязательно вызываем logout().
const crypto = require("crypto");

class IikoClient {
  constructor({ baseUrl, login, password }) {
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.login = login;
    this.passHash = crypto.createHash("sha1").update(password).digest("hex");
    this.token = null;
  }

  async auth() {
    const url = `${this.baseUrl}/resto/api/auth?login=${encodeURIComponent(this.login)}&pass=${this.passHash}`;
    const r = await fetch(url);
    if (!r.ok) throw new Error(`iiko auth: HTTP ${r.status}`);
    this.token = (await r.text()).trim();
    return this.token;
  }

  async logout() {
    if (!this.token) return;
    await fetch(`${this.baseUrl}/resto/api/logout?key=${this.token}`).catch(() => {});
    this.token = null;
  }

  async request(path, { method = "GET", body } = {}) {
    if (!this.token) await this.auth();
    const sep = path.includes("?") ? "&" : "?";
    const r = await fetch(`${this.baseUrl}${path}${sep}key=${this.token}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    if (r.status === 401) { this.token = null; return this.request(path, { method, body }); }
    if (!r.ok) {
      const txt = (await r.text().catch(() => "")).replace(/\s+/g, " ").trim();
      throw new Error(`iiko ${path.split("?")[0]}: HTTP ${r.status}${txt ? " — " + txt.slice(0, 400) : ""}`);
    }
    const type = r.headers.get("content-type") || "";
    return type.includes("json") ? r.json() : r.text();
  }

  // Список доступных полей OLAP — запустить один раз и сверить имена полей ниже
  // с конкретной версией сервера.
  olapColumns(reportType = "SALES") {
    return this.request(`/resto/api/v2/reports/olap/columns?reportType=${reportType}`);
  }

  // Продажи по часам/блюдам/официантам за период. from/to — 'YYYY-MM-DD'.
  async sales(from, to, groupBy = ["Department", "HourOpen"]) {
    const body = {
      reportType: "SALES",
      buildSummary: "false",
      groupByRowFields: groupBy,
      aggregateFields: [
        "DishDiscountSumInt",          // выручка со скидкой
        "ProductCostBase.ProductCost", // себестоимость
        "UniqOrderId.OrdersCount",     // число чеков
        "GuestNum",                    // гостей
        "DishAmountInt",               // количество
      ],
      filters: {
        "OpenDate.Typed": { filterType: "DateRange", periodType: "CUSTOM", from, to, includeLow: true, includeHigh: false },
        "DeletedWithWriteoff": { filterType: "IncludeValues", values: ["NOT_DELETED"] },
        "OrderDeleted": { filterType: "IncludeValues", values: ["NOT_DELETED"] },
      },
    };
    const res = await this.request("/resto/api/v2/reports/olap", { method: "POST", body });
    return res.data || [];
  }

  // Универсальный OLAP-запрос по продажам (без удалённых позиций).
  async olap(from, to, groupBy, aggregates, extraFilters = {}) {
    const body = {
      reportType: "SALES",
      buildSummary: "false",
      groupByRowFields: groupBy,
      aggregateFields: aggregates,
      filters: {
        "OpenDate.Typed": { filterType: "DateRange", periodType: "CUSTOM", from, to, includeLow: true, includeHigh: false },
        "DeletedWithWriteoff": { filterType: "IncludeValues", values: ["NOT_DELETED"] },
        "OrderDeleted": { filterType: "IncludeValues", values: ["NOT_DELETED"] },
        ...extraFilters,
      },
    };
    const res = await this.request("/resto/api/v2/reports/olap", { method: "POST", body });
    return res.data || [];
  }

  // Строки продаж с точным временем — нужны для сверки с видео.
  async salesLines(from, to) {
    return this.sales(from, to, ["Department", "OpenTime", "DishName", "DishCategory", "OrderNum", "OrderWaiter.Name", "CashRegisterName"]);
  }

  // Удалённые позиции и заказы (отмены, сторно).
  async deletions(from, to) {
    const body = {
      reportType: "SALES",
      buildSummary: "false",
      groupByRowFields: ["Department", "OpenTime", "OrderNum", "DishName", "OrderWaiter.Name", "DeletedWithWriteoff", "OrderDeleted", "RemovalType"],
      aggregateFields: ["DishSumInt", "DishAmountInt"],
      filters: {
        "OpenDate.Typed": { filterType: "DateRange", periodType: "CUSTOM", from, to, includeLow: true, includeHigh: false },
        "DeletedWithWriteoff": { filterType: "ExcludeValues", values: ["NOT_DELETED"] },
      },
    };
    const res = await this.request("/resto/api/v2/reports/olap", { method: "POST", body });
    return res.data || [];
  }

  // Журнал событий кассы (пречек, открытие ящика, удаления, скидки).
  // Возвращает XML; типы событий маппятся в config.iiko.eventTypes.
  events(fromIso, toIso) {
    return this.request(`/resto/api/events?from_time=${encodeURIComponent(fromIso)}&to_time=${encodeURIComponent(toIso)}`);
  }

  employees() { return this.request("/resto/api/employees"); }
}

// Простой разбор XML событий iiko в плоский список (без внешних библиотек).
function parseEvents(xml, typeMap) {
  const out = [];
  for (const m of xml.matchAll(/<event>([\s\S]*?)<\/event>/g)) {
    const get = (tag) => (m[1].match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`)) || [])[1];
    const type = get("type");
    const attrs = {};
    for (const a of m[1].matchAll(/<attribute><name>(.*?)<\/name><value>(.*?)<\/value><\/attribute>/g)) attrs[a[1]] = a[2];
    out.push({ ts: new Date(get("date")), type: typeMap[type] || type, raw: type, attrs });
  }
  return out;
}

module.exports = { IikoClient, parseEvents };
