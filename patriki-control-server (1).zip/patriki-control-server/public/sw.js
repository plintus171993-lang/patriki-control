// Service worker «Патрики Контроль».
// Оболочка приложения кэшируется для быстрого запуска и офлайн-заставки.
// Данные (/api/*) никогда не кэшируются — только свежие из iiko.
const VERSION = "pk-v1";
const SHELL = ["/", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin || url.pathname.startsWith("/api/")) return;

  // Страница: сначала сеть (чтобы обновления приходили сразу), при обрыве — сохранённая версия.
  if (e.request.mode === "navigate") {
    e.respondWith(
      fetch(e.request).then((r) => {
        const copy = r.clone();
        caches.open(VERSION).then((c) => c.put("/", copy));
        return r;
      }).catch(() => caches.match("/"))
    );
    return;
  }
  // Иконки и манифест: из кэша, иначе из сети.
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request)));
});
