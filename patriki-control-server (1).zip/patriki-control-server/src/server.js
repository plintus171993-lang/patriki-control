// HTTP-сервер приложения руководителя (без внешних зависимостей, Node 18+).
//   GET  /api/ping                                   — проверка, без ключа
//   GET  /api/dashboard?venue=pet&period=day|yesterday|week|month — живые данные iiko
//   GET  /api/incidents?venue=pet                    — инциденты сверки видео ↔ касса
//   POST /api/incidents/:id  {status:"ok"|"fp"|"new"} — разбор инцидента
//   POST /api/vision/events  [{camera,type,ts,...}]   — приём событий видеоаналитики
//   GET  /                                           — приложение (public/index.html)
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { IikoClient, parseEvents } = require("./iiko");
const { reconcile } = require("./rules");
const { dashboard } = require("./reports");

const ROOT = path.join(__dirname, "..");
const cfg = JSON.parse(fs.readFileSync(process.env.CONFIG || path.join(ROOT, "config.json"), "utf8"));
const DEMO = cfg.demo === true;

const store = { vision: [], incidents: new Map() };
const iiko = Object.fromEntries(
  Object.entries(cfg.venues).filter(([, v]) => v.iiko && !DEMO).map(([k, v]) => [k, new IikoClient(v.iiko)])
);

async function loadPos(venue) {
  if (DEMO || !iiko[venue]) return require("../demo/pos.json").map((e) => ({ ...e, ts: new Date(e.ts) }));
  const now = new Date(), from = new Date(now - 12 * 3600e3);
  const xml = await iiko[venue].events(from.toISOString(), now.toISOString());
  await iiko[venue].logout();
  return parseEvents(xml, cfg.iiko.eventTypes).map((e) => ({ ...e, venue, ...normalize(e) }));
}
function normalize(e) {
  const a = e.attrs || {};
  return { terminal: a.cashRegister, employee: a.user, order: a.orderNum, sum: Number(a.sum) || null,
           category: a.productCategory, table: a.tableNum, percent: Number(a.discountPercent) || 0,
           afterPrecheque: a.prechequePrinted === "true", loyaltyCard: !!a.cardNumber, reason: a.reason };
}

async function runReconcile(venue) {
  const pos = await loadPos(venue);
  const vision = store.vision.filter((v) => v.venue === venue);
  for (const inc of reconcile({ vision, pos, cfg })) {
    if (!store.incidents.has(inc.id)) store.incidents.set(inc.id, inc);
  }
}

const SEC_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "Cache-Control": "no-store",
};
function send(res, code, data, type = "application/json; charset=utf-8") {
  res.writeHead(code, { "Content-Type": type, ...SEC_HEADERS });
  res.end(typeof data === "string" || Buffer.isBuffer(data) ? data : JSON.stringify(data));
}
function body(req) {
  return new Promise((ok, fail) => {
    let b = "";
    req.on("data", (c) => { b += c; if (b.length > 1e6) req.destroy(); });
    req.on("end", () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { fail(new Error("Неверный JSON")); } });
  });
}
function authorized(req) {
  if (!cfg.apiToken) return true;
  const got = Buffer.from(String(req.headers.authorization || ""));
  const want = Buffer.from(`Bearer ${cfg.apiToken}`);
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  try {
    if (url.pathname === "/api/ping") {
      return send(res, 200, { ok: true, demo: DEMO, venues: Object.fromEntries(Object.entries(cfg.venues).map(([k, v]) => [k, { name: v.name, connected: !!v.iiko }])) });
    }
    if (url.pathname.startsWith("/api/") && !authorized(req)) return send(res, 401, { error: "Нужен ключ доступа" });

    if (url.pathname === "/api/dashboard") {
      const venue = url.searchParams.get("venue") || "pet";
      const period = url.searchParams.get("period") || "day";
      if (DEMO) return send(res, 200, { live: false });
      if (!iiko[venue]) return send(res, 200, { live: false, notConnected: true, venue });
      return send(res, 200, await dashboard(iiko[venue], venue, period));
    }
    if (url.pathname === "/api/incidents" && req.method === "GET") {
      const venue = url.searchParams.get("venue") || "pet";
      await runReconcile(venue).catch(() => {});
      return send(res, 200, [...store.incidents.values()].filter((i) => i.venue === venue));
    }
    const m = url.pathname.match(/^\/api\/incidents\/(.+)$/);
    if (m && req.method === "POST") {
      const inc = store.incidents.get(decodeURIComponent(m[1]));
      if (!inc) return send(res, 404, { error: "Инцидент не найден" });
      const st = (await body(req)).status;
      if (!["ok", "fp", "new"].includes(st)) return send(res, 400, { error: "status: ok | fp | new" });
      inc.status = st;
      return send(res, 200, inc);
    }
    if (url.pathname === "/api/vision/events" && req.method === "POST") {
      const list = [].concat(await body(req)).map((e) => ({ venue: "pet", ...e, ts: new Date(e.ts) }));
      store.vision.push(...list);
      if (store.vision.length > 50000) store.vision.splice(0, store.vision.length - 50000);
      return send(res, 202, { accepted: list.length });
    }
    if (url.pathname === "/" || url.pathname === "/index.html") {
      let html = fs.readFileSync(path.join(ROOT, "public", "index.html"), "utf8");
      if (!/^\s*<!doctype/i.test(html)) {
        html = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">` +
          `<meta name="theme-color" content="#1f5c43"><link rel="manifest" href="/manifest.webmanifest">` +
          `<link rel="icon" href="/icon-192.png"><link rel="apple-touch-icon" href="/apple-touch-icon.png">` +
          `<meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="Патрики">` +
          `<style>:root{padding-top:env(safe-area-inset-top);padding-bottom:env(safe-area-inset-bottom)}body{margin:0}[hidden]{display:none!important}</style>` +
          `<script>if("serviceWorker" in navigator)addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}))</script>` +
          `</head><body>${html}</body></html>`;
      }
      return send(res, 200, html, "text/html; charset=utf-8");
    }
    const STATIC = {
      "/manifest.webmanifest": "application/manifest+json",
      "/sw.js": "text/javascript; charset=utf-8",
      "/icon-192.png": "image/png",
      "/icon-512.png": "image/png",
      "/apple-touch-icon.png": "image/png",
    };
    if (STATIC[url.pathname]) {
      const file = path.join(ROOT, "public", url.pathname.slice(1));
      if (fs.existsSync(file)) return send(res, 200, fs.readFileSync(file), STATIC[url.pathname]);
    }
    send(res, 404, { error: "Не найдено" });
  } catch (e) {
    console.error(new Date().toISOString(), url.pathname, e.message);
    send(res, 502, { error: e.message });
  }
});

if (require.main === module) {
  if (DEMO) store.vision.push(...require("../demo/vision.json").map((e) => ({ ...e, ts: new Date(e.ts) })));
  const port = cfg.port || 8080;
  server.listen(port, cfg.host || "0.0.0.0", () => console.log(`Патрики Контроль: порт ${port}${DEMO ? " (демо)" : ""}`));
  const stop = async () => { await Promise.all(Object.values(iiko).map((c) => c.logout())); process.exit(0); };
  process.on("SIGINT", stop); process.on("SIGTERM", stop);
}
module.exports = { server, store, runReconcile };
