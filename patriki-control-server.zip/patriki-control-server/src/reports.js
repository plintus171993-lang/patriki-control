// Отчёты для приложения руководителя: периоды по московскому времени,
// запросы к iiko одной сессией (вход → запросы → выход, чтобы не держать
// лицензию), кэш на 5 минут.
const CACHE_MS = 5 * 60 * 1000;
const cache = new Map();

const num = (v) => Number(v) || 0;
const ymd = (d) => d.toLocaleDateString("sv-SE", { timeZone: "Europe/Moscow" }); // YYYY-MM-DD
const addDays = (s, n) => { const d = new Date(s + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };

// Рабочий день паба заканчивается ночью, поэтому «сегодня» до 06:00 — это ещё вчерашний день.
function businessToday() {
  const now = new Date();
  const h = Number(now.toLocaleString("en-GB", { timeZone: "Europe/Moscow", hour: "2-digit", hour12: false }));
  return h < 6 ? addDays(ymd(now), -1) : ymd(now);
}

function periodRange(period) {
  const today = businessToday();
  if (period === "yesterday") return { from: addDays(today, -1), to: today, prevFrom: addDays(today, -8), prevTo: addDays(today, -7), label: "к тому же дню неделю назад" };
  if (period === "week") return { from: addDays(today, -6), to: addDays(today, 1), prevFrom: addDays(today, -13), prevTo: addDays(today, -6), label: "к прошлой неделе" };
  if (period === "month") return { from: addDays(today, -29), to: addDays(today, 1), prevFrom: addDays(today, -59), prevTo: addDays(today, -29), label: "к прошлым 30 дням" };
  return { from: today, to: addDays(today, 1), prevFrom: addDays(today, -7), prevTo: addDays(today, -6), label: "к тому же дню неделю назад" };
}

async function cached(key, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < CACHE_MS) return hit.v;
  const v = await fn();
  cache.set(key, { t: Date.now(), v });
  return v;
}

// Одна сессия на пакет запросов; клиенты iiko не допускают параллельный вход одним токеном — идём последовательно.
let queue = Promise.resolve();
function session(client, fn) {
  const run = queue.then(async () => {
    try { return await fn(client); } finally { await client.logout(); }
  });
  queue = run.catch(() => {});
  return run;
}

const AGG = ["DishDiscountSumInt", "ProductCostBase.ProductCost", "UniqOrderId.OrdersCount", "GuestNum"];

function totals(rows) {
  const rev = rows.reduce((a, r) => a + num(r.DishDiscountSumInt), 0);
  const cost = rows.reduce((a, r) => a + num(r["ProductCostBase.ProductCost"]), 0);
  const checks = rows.reduce((a, r) => a + num(r["UniqOrderId.OrdersCount"]), 0);
  const guests = rows.reduce((a, r) => a + num(r.GuestNum), 0);
  return { revenue: rev, cost, gross: rev - cost, checks, guests, avgCheck: checks ? rev / checks : 0, foodcostPct: rev ? (cost / rev) * 100 : 0 };
}

async function dashboard(client, venueKey, period) {
  const p = periodRange(period);
  return cached(`${venueKey}:${period}:${p.from}`, () => session(client, async (c) => {
    const cur = await c.olap(p.from, p.to, ["Department"], AGG);
    const prev = await c.olap(p.prevFrom, p.prevTo, ["Department"], AGG);
    const hours = await c.olap(p.from, p.to, ["HourOpen"], ["DishDiscountSumInt"]);
    const dishes = await c.olap(p.from, p.to, ["DishName"], ["DishDiscountSumInt", "DishAmountInt", "ProductCostBase.ProductCost"]);
    const cats = await c.olap(p.from, p.to, ["DishCategory"], ["DishDiscountSumInt"]);
    const pays = await c.olap(p.from, p.to, ["PayTypes"], ["DishDiscountSumInt"]).catch(() => []);
    const waiters = await c.olap(p.from, p.to, ["OrderWaiter.Name"], ["DishDiscountSumInt", "UniqOrderId.OrdersCount"]);
    let deletions = [];
    let deletionsError = null;
    try { deletions = await c.deletions(p.from, p.to); } catch (e) { deletionsError = e.message; }

    const staff = new Map();
    for (const w of waiters) {
      const n = w["OrderWaiter.Name"] || "Без официанта";
      staff.set(n, { name: n, revenue: num(w.DishDiscountSumInt), checks: num(w["UniqOrderId.OrdersCount"]), deletions: 0, deletedSum: 0 });
    }
    for (const d of deletions) {
      const n = d["OrderWaiter.Name"] || "Без официанта";
      const s = staff.get(n) || { name: n, revenue: 0, checks: 0, deletions: 0, deletedSum: 0 };
      s.deletions += 1; s.deletedSum += num(d.DishSumInt);
      staff.set(n, s);
    }

    const sortRev = (a, b) => b.revenue - a.revenue;
    return {
      live: true, venue: venueKey, period, from: p.from, to: addDays(p.to, -1), compareLabel: p.label,
      updatedAt: new Date().toISOString(),
      totals: totals(cur), previous: totals(prev),
      byHour: hours.map((r) => ({ hour: num(r.HourOpen), revenue: num(r.DishDiscountSumInt) })).sort((a, b) => ((a.hour + 18) % 24) - ((b.hour + 18) % 24)),
      topDishes: dishes.map((r) => ({ name: r.DishName, qty: num(r.DishAmountInt), revenue: num(r.DishDiscountSumInt), cost: num(r["ProductCostBase.ProductCost"]) })).sort(sortRev).slice(0, 15),
      categories: cats.map((r) => ({ name: r.DishCategory || "Без категории", revenue: num(r.DishDiscountSumInt) })).sort(sortRev),
      payments: pays.map((r) => ({ name: r.PayTypes || "Не указано", revenue: num(r.DishDiscountSumInt) })).sort(sortRev),
      staff: [...staff.values()].sort(sortRev),
      deletionsError,
    };
  }));
}

module.exports = { dashboard, periodRange, businessToday };
